"""LIMEN v0.5 multiplayer pilot.
- Server-authoritative loot, masks, claims, item geometry, arrests, moderation.
- SQLite WAL persistence; guest accounts secured by random bearer token.
- Single Uvicorn worker; scale-out requires Redis pubsub/shared state.
"""
import asyncio, hmac, hashlib, json, math, os, random, re, secrets, sqlite3, time, uuid
from pathlib import Path
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from world import (ROLES, ROLE, ITEMS, BAGS, CAPSULE_COUNT, PODS_PER_SECTOR, WORLD_WIDTH,
                   room_for, capsule_pos, room_npcs, corridor_npcs, weighted_mask, item_fits)

ROOT=Path(__file__).parent
DB_PATH=Path(os.environ.get('LIMEN_DB_PATH',str(ROOT/'data'/'limen.sqlite3'))).resolve()
DB_PATH.parent.mkdir(exist_ok=True,parents=True)
DB=sqlite3.connect(str(DB_PATH),check_same_thread=False,isolation_level=None)
DB.row_factory=sqlite3.Row
DB.execute('PRAGMA journal_mode=WAL')
DB.execute('PRAGMA foreign_keys=ON')
DB.executescript('''
CREATE TABLE IF NOT EXISTS players (
 id TEXT PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
 sector INTEGER NOT NULL DEFAULT 1, scene TEXT NOT NULL DEFAULT 'corridor', room_id INTEGER NOT NULL DEFAULT 0,
 x REAL NOT NULL DEFAULT 190, y REAL NOT NULL DEFAULT 310,
 health REAL NOT NULL DEFAULT 100, food REAL NOT NULL DEFAULT 100, water REAL NOT NULL DEFAULT 100,
 bag TEXT NOT NULL DEFAULT 'none', equip_id TEXT, level INTEGER NOT NULL DEFAULT 1,
 wanted INTEGER NOT NULL DEFAULT 0, crime TEXT NOT NULL DEFAULT '',
 jail_until REAL NOT NULL DEFAULT 0, dispenser_at REAL NOT NULL DEFAULT 0,
 banned INTEGER NOT NULL DEFAULT 0, ban_reason TEXT NOT NULL DEFAULT '',
 created_at REAL NOT NULL, updated_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS inventory (
 id TEXT PRIMARY KEY, player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 type TEXT NOT NULL, qty INTEGER NOT NULL DEFAULT 1,
 role TEXT, variant TEXT, element TEXT, form TEXT,
 x INTEGER, y INTEGER
);
CREATE TABLE IF NOT EXISTS claims (
 capsule_id INTEGER PRIMARY KEY, player_id TEXT UNIQUE NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 claimed_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS searched (player_id TEXT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 capsule_id INTEGER NOT NULL, PRIMARY KEY(player_id,capsule_id));
CREATE TABLE IF NOT EXISTS chat (id INTEGER PRIMARY KEY AUTOINCREMENT, player_id TEXT, sector INTEGER NOT NULL,
 scene TEXT NOT NULL, room_id INTEGER NOT NULL, name TEXT NOT NULL, body TEXT NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS warrants (target_id TEXT PRIMARY KEY, reason TEXT NOT NULL, created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS audit (id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, action TEXT NOT NULL,
 target TEXT, detail TEXT, created_at REAL NOT NULL);
CREATE INDEX IF NOT EXISTS idx_inventory_player ON inventory(player_id);
''')

def q(sql,args=()):return DB.execute(sql,args)
def one(sql,args=()):return q(sql,args).fetchone()
def rows(sql,args=()):return [dict(r) for r in q(sql,args).fetchall()]
def tokenhash(token):return hashlib.sha256(token.encode()).hexdigest()
def now():return time.time()
def new_id():return uuid.uuid4().hex

def player_by_token(token):
 if not token or not isinstance(token,str) or len(token)>200:return None
 try:return dict(one('SELECT * FROM players WHERE token_hash=?',(tokenhash(token),)) or {}) or None
 except Exception:return None

def sanitize_name(name):
 name=re.sub(r'\s+',' ',str(name).strip())[:22]
 name=re.sub(r'[<>\r\n\\]','',name)
 if len(name)<2:raise ValueError('Nombre demasiado corto.')
 return name

def player_items(pid):
 return rows('SELECT * FROM inventory WHERE player_id=? ORDER BY rowid',(pid,))

def equipped_role(p):
 if not p.get('equip_id'):return None
 item=one('SELECT type,role,variant,element,form FROM inventory WHERE id=? AND player_id=?',(p['equip_id'],p['id']))
 return dict(item) if item and item['type']=='mask' else None

def role_id(p):
 item=equipped_role(p)
 return item['role'] if item else 'civil'

def hostile(p):
 item=equipped_role(p)
 return bool(item and item['role']=='anomalo' and item['variant']=='hostile')

def card_level(p):
 r=role_id(p)
 if r=='oficial':return 99
 return max([1,*[int(i['type'][-1]) for i in player_items(p['id']) if i['type'].startswith('access') and i['type'][-1].isdigit()],
             3 if r in ('director','inquisidor','comandante') else 2 if r in ('seguridad','policia','medico','medicocombate','contencion','respuesta','auditor') else 1])

def compact_player(p,viewer=None):
 r=role_id(p)
 data={'id':p['id'],'name':p['name'],'sector':p['sector'],'scene':p['scene'],'room':p['room_id'],
       'x':round(p['x'],1),'y':round(p['y'],1),'health':round(p['health']),
       'role':r,'hostile':hostile(p),'wanted':bool(p['wanted']),
       'jailed':p['jail_until']>now(),'stunned': bool(online.get(p['id']) and online[p['id']].stun_until>now())}
 # The special officer's scanner identifies an infiltrator only when nearby in same scene.
 if viewer and role_id(viewer)=='oficial' and viewer['sector']==p['sector'] and viewer['scene']==p['scene'] and viewer['room_id']==p['room_id'] and math.dist((p['x'],p['y']),(viewer['x'],viewer['y']))<140:
  if r=='infiltrado':data['scan']='INFILTRADO IDENTIFICADO'
 return data

def player_data(p):
 items=player_items(p['id']);eq=equipped_role(p)
 claim=one('SELECT capsule_id FROM claims WHERE player_id=?',(p['id'],))
 return {**compact_player(p),'food':round(p['food']),'water':round(p['water']),
         'bag':p['bag'],'inventory':items,'equip':p['equip_id'],'equipped':eq,
         'claim':claim['capsule_id'] if claim else None,'cardLevel':card_level(p),
         'crime':p['crime'],'jailUntil':p['jail_until'],'dispenserAt':p['dispenser_at'],
         'level':p['level'],'inquisitorOrder':bool(one('SELECT 1 FROM warrants WHERE target_id=?',(p['id'],)))}

def inventory_positions(pid,bag=None):
 p=one('SELECT bag FROM players WHERE id=?',(pid,))
 if not p:return None
 bag=bag or p['bag'];items=player_items(pid)
 return item_fits(items,bag,None)

def add_item(pid,kind,**meta):
 if kind not in ITEMS: return None
 p=one('SELECT bag FROM players WHERE id=?',(pid,))
 if not p:return None
 items=player_items(pid)
 # Stack before using additional geometry, except masks and high-value items.
 limit=ITEMS[kind]['stack']
 if limit>1:
  for i in items:
   if i['type']==kind and i['qty']<limit:
    q('UPDATE inventory SET qty=qty+1 WHERE id=?',(i['id'],));return i['id']
 entry={'id':new_id(),'type':kind, 'x':None,'y':None}
 positions=item_fits(items,p['bag'],entry)
 if positions is None:return None
 pos=positions[entry['id']]
 q('INSERT INTO inventory (id,player_id,type,qty,role,variant,element,form,x,y) VALUES (?,?,?,?,?,?,?,?,?,?)',
   (entry['id'],pid,kind,1,meta.get('role'),meta.get('variant'),meta.get('element'),meta.get('form'),pos['x'],pos['y']))
 return entry['id']

def item_remove(pid,item):
 if item['qty']>1:q('UPDATE inventory SET qty=qty-1 WHERE id=? AND player_id=?',(item['id'],pid))
 else:q('DELETE FROM inventory WHERE id=? AND player_id=?',(item['id'],pid))

def save_player(p):
 q('UPDATE players SET sector=?,scene=?,room_id=?,x=?,y=?,health=?,food=?,water=?,wanted=?,crime=?,jail_until=?,updated_at=? WHERE id=?',
   (p['sector'],p['scene'],p['room_id'],p['x'],p['y'],p['health'],p['food'],p['water'],p['wanted'],p['crime'],p['jail_until'],now(),p['id']))

def all_sector_capsules(sector):
 cids=range((sector-1)*PODS_PER_SECTOR+1,min(sector*PODS_PER_SECTOR,CAPSULE_COUNT)+1)
 out=[]
 for cid in cids:
  p=capsule_pos(cid);owner=one('SELECT p.name FROM claims c JOIN players p ON p.id=c.player_id WHERE c.capsule_id=?',(cid,))
  out.append({'id':cid,'x':p[0],'y':p[1],'owned':owner['name'] if owner else None})
 return out

class Runtime:
 def __init__(self,p):
  self.p=p;self.ws=None;self.dx=0;self.dy=0;self.last_chat=0;self.last_search=0;self.last_interact=0
  self.last_hit=0;self.last_stun=0;self.last_knock=0;self.stun_until=0;self.dirty=False;self.online=False;self.admin=False;self.last_send=0;self.last_input=now();self.last_food=now()

online={}; active_sockets=set(); recent_chat=deque(maxlen=80); admin_failures=defaultdict(deque)
admin_code=os.environ.get('LIMEN_ADMIN_CODE','')

async def send(rt,payload):
 if rt.ws:
  try:await rt.ws.send_json(payload)
  except Exception:pass
async def msg(rt,txt,kind='info'):
 await send(rt,{'type':'notice','message':txt,'kind':kind})
async def refresh(rt):
 # DB-modified scalar fields may have changed.
 p=one('SELECT * FROM players WHERE id=?',(rt.p['id'],))
 if p:
  for k in ('bag','equip_id','dispenser_at','banned','ban_reason','level','jail_until'):
   rt.p[k]=p[k]
 await send(rt,{'type':'self','player':player_data(rt.p)})

async def collision_guard(rt,target_id,distance=85):
 if target_id==rt.p['id']:return None
 rt2=online.get(target_id)
 if not rt2:return None
 a,b=rt.p,rt2.p
 if a['scene']!=b['scene'] or a['sector']!=b['sector'] or a['room_id']!=b['room_id']:return None
 if math.dist((a['x'],a['y']),(b['x'],b['y']))>distance:return None
 return rt2

async def do_action(rt,data):
 p=rt.p;pid=p['id'];act=data.get('action','');t=now()
 if p['jail_until']>t and act not in ('chat','status'):raise ValueError('Estás detenido. Espera a que termine tu sanción.')
 if act=='enter':
  cid=int(data.get('id',0));room=room_for(cid)
  if not room or room['sector']!=p['sector'] or p['scene']!='corridor':raise ValueError('No estás junto a esa cápsula.')
  if math.dist((p['x'],p['y']),capsule_pos(cid))>142:raise ValueError('Acércate a la puerta.')
  if card_level(p)<room['access']:raise ValueError('Tarjeta de acceso insuficiente: se requiere nivel '+str(room['access']))
  p.update(scene='room',room_id=cid,x=620.0,y=370.0);save_player(p)
  await msg(rt,'Cápsula '+str(cid)+' · '+room['name'])
 elif act=='leave':
  if p['scene']!='room':raise ValueError('No estás dentro de una cápsula.')
  p['x'],p['y']=capsule_pos(p['room_id']);p['scene']='corridor';p['room_id']=0;save_player(p)
 elif act=='sector':
  diff=int(data.get('delta',0))
  if p['scene']!='corridor' or diff not in (-1,1):raise ValueError('Tránsito no disponible.')
  if diff==1 and p['x']<WORLD_WIDTH-230 or diff==-1 and p['x']>260:raise ValueError('Dirígete al ascensor del extremo del pasillo.')
  target=p['sector']+diff
  if not 1<=target<=math.ceil(CAPSULE_COUNT/PODS_PER_SECTOR):raise ValueError('Fin de la instalación registrada.')
  p['sector']=target;p['x']=200 if diff>0 else WORLD_WIDTH-200;p['y']=310;save_player(p)
 elif act=='claim':
  if p['scene']!='room':raise ValueError('Debes entrar en la vivienda.')
  room=room_for(p['room_id'])
  if room['type']!='home':raise ValueError('Esta cápsula no es una vivienda reclamable.')
  if one('SELECT capsule_id FROM claims WHERE player_id=?',(pid,)):raise ValueError('Solo puedes reclamar una vivienda.')
  if one('SELECT player_id FROM claims WHERE capsule_id=?',(p['room_id'],)):raise ValueError('Esta residencia ya está reclamada.')
  q('INSERT INTO claims (capsule_id,player_id,claimed_at) VALUES (?,?,?)',(p['room_id'],pid,t));await msg(rt,'Residencia registrada a tu nombre.','good')
 elif act=='unclaim':
  if p['scene']!='room' or not one('SELECT 1 FROM claims WHERE capsule_id=? AND player_id=?',(p['room_id'],pid)):
   raise ValueError('No es tu vivienda.')
  q('DELETE FROM claims WHERE player_id=?',(pid,));await msg(rt,'Has abandonado la residencia.')
 elif act=='rest':
  if p['scene']!='room' or room_for(p['room_id'])['type']!='home':raise ValueError('Solo puedes descansar en una cápsula residencial.')
  owner=one('SELECT player_id FROM claims WHERE capsule_id=?',(p['room_id'],))
  if owner and owner['player_id']!=pid:
   p['wanted']=1;p['crime']='Uso residencial de habitación ajena';save_player(p)
   q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',
     (pid,'illegal_occupancy',str(p['room_id']),'Descanso registrado dentro de una vivienda ajena.',t))
   await msg(rt,'OCUPACIÓN ILEGAL: descanso en una vivienda registrada a otra persona.','danger')
  else:
   p['health']=min(100,p['health']+8);save_player(p)
   await msg(rt,'Has descansado.','good')
 elif act=='dispense':
  if p['scene']!='room' or not one('SELECT 1 FROM claims WHERE player_id=? AND capsule_id=?',(pid,p['room_id'])):raise ValueError('Solo funciona en tu habitación reclamada.')
  if t-p['dispenser_at']<20:raise ValueError('Siguiente ración en '+str(math.ceil(20-(t-p['dispenser_at'])))+' s.')
  if not add_item(pid,'ration'):raise ValueError('No cabe otra ración en el inventario.')
  p['dispenser_at']=t;q('UPDATE players SET dispenser_at=? WHERE id=?',(t,pid));await msg(rt,'Ración recogida. Siguiente suministro en 20 s.','good')
 elif act=='search':
  if p['scene']!='room':raise ValueError('Busca dentro de las cápsulas.')
  if t-rt.last_search<2:raise ValueError('Espera antes de registrar otra zona.')
  rt.last_search=t;cid=p['room_id'];room=room_for(cid)
  if one('SELECT 1 FROM searched WHERE player_id=? AND capsule_id=?',(pid,cid)):
   raise ValueError('Ya registraste esta cápsula.')
  if random.random()<.27:
   m=weighted_mask(room)
   ident=add_item(pid,'mask',**m)
   found='Máscara: '+ROLE[m['role']]['name'] if ident else 'No tienes espacio para la máscara.'
  else:
   common=['ration','water','battery','medkit','scanner','armor','bag_small','bag_medium','bag_large','weapon_pistol','weapon_rifle','access2','access3','access4']
   weights=[22,18,10,13,5,3,7,3,1,3,1,7,3,1]
   if random.random()<.11:found='No encontraste nada útil.'
   else:
    kind=random.choices(common,weights=weights)[0];ident=add_item(pid,kind)
    found='Encontraste '+ITEMS[kind]['name'] if ident else 'Encontraste un objeto, pero no tienes espacio.'
  q('INSERT INTO searched (player_id,capsule_id) VALUES (?,?)',(pid,cid))
  await msg(rt,found,'good')
 elif act=='item':
  ident=str(data.get('id',''))[:45];it=one('SELECT * FROM inventory WHERE id=? AND player_id=?',(ident,pid))
  if not it:raise ValueError('No tienes ese objeto.')
  it=dict(it);kind=it['type'];use=str(data.get('use',''))
  if use=='equip':
   if kind=='mask':
    q('UPDATE players SET equip_id=? WHERE id=?',(ident,pid));p['equip_id']=ident
    if it['variant']=='hostile':p['wanted']=1;p['crime']='Entidad anómala hostil';save_player(p)
    await msg(rt,'Máscara equipada: '+ROLE[it['role']]['name'],'good')
   elif kind.startswith('bag_'):
    bag=kind.split('_')[1]
    current=player_items(pid)
    positions=item_fits(current,bag,None)
    if positions is None:raise ValueError('Los objetos no caben en esa mochila.')
    q('BEGIN IMMEDIATE')
    try:
     for iid,pos in positions.items():q('UPDATE inventory SET x=?,y=? WHERE id=? AND player_id=?',(pos['x'],pos['y'],iid,pid))
     q('UPDATE players SET bag=? WHERE id=?',(bag,pid))
     q('COMMIT')
    except Exception:
     q('ROLLBACK');raise
    p['bag']=bag;await msg(rt,'Mochila equipada.','good')
   else:raise ValueError('Este objeto no se equipa aquí.')
  elif use=='unequip':
   if kind=='mask' and ident==p['equip_id']:
    q('UPDATE players SET equip_id=NULL WHERE id=?',(pid,));p['equip_id']=None
    # Hostility is determined by the mask; crimes can remain.
    await msg(rt,'Máscara retirada.','good')
   else:raise ValueError('Ese objeto no está equipado.')
  elif use=='consume':
   if kind=='ration':p['food']=min(100,p['food']+35)
   elif kind=='water':p['water']=min(100,p['water']+40)
   elif kind=='medkit':p['health']=min(100,p['health']+30)
   else:raise ValueError('No puedes consumir ese objeto.')
   item_remove(pid,it);save_player(p);await msg(rt,'Objeto utilizado.','good')
  elif use=='move':
   xy=data.get('xy')
   if not isinstance(xy,list) or len(xy)!=2:raise ValueError('Posición no válida.')
   bag=p['bag'];cols,rs=BAGS[bag]
   x,y=map(int,xy)
   current=player_items(pid)
   others=[i for i in current if i['id']!=ident]
   candidate={**it,'x':None,'y':None}
   # Validate no overlaps with fixed positions; then save only target's new position.
   w,h=ITEMS[kind]['size'];occupied=set()
   for i in others:
    iw,ih=ITEMS[i['type']]['size']
    for xx in range(i['x'],i['x']+iw):
     for yy in range(i['y'],i['y']+ih):occupied.add((xx,yy))
   if not(0<=x and 0<=y and x+w<=cols and y+h<=rs) or any((xx,yy) in occupied for xx in range(x,x+w) for yy in range(y,y+h)):
    raise ValueError('El objeto no cabe en esa posición.')
   q('UPDATE inventory SET x=?,y=? WHERE id=? AND player_id=?',(x,y,ident,pid));await msg(rt,'Objeto reorganizado.','good')
  else:raise ValueError('Acción de objeto desconocida.')
 elif act=='chat':
  if t-rt.last_chat<.85:raise ValueError('Hablas demasiado rápido.')
  body=re.sub(r'[\x00-\x1f]','',str(data.get('text','')).strip())[:220]
  if not body:raise ValueError('Mensaje vacío.')
  rt.last_chat=t
  q('INSERT INTO chat (player_id,sector,scene,room_id,name,body,created_at) VALUES (?,?,?,?,?,?,?)',
    (pid,p['sector'],p['scene'],p['room_id'],p['name'],body,t))
  recent_chat.append({'name':p['name'],'body':body,'sector':p['sector'],'scene':p['scene'],'room':p['room_id'],'time':t})
 elif act=='arrest':
  rt2=await collision_guard(rt,str(data.get('target','')),105)
  if not rt2:raise ValueError('El sospechoso no está a tu alcance.')
  other=rt2.p;r=role_id(p);other_r=role_id(other)
  if r not in ('policia','oficial','auditor'):raise ValueError('Tu clase no tiene autoridad para arrestar jugadores.')
  if other_r=='oficial' and r not in ('oficial','auditor'):raise ValueError('La Policía ordinaria no puede arrestar a un Oficial Militar.')
  if other_r=='director' and r=='policia':raise ValueError('La jurisdicción ordinaria no permite detener a un Director de Zona sin habilitación especial.')
  if r=='auditor' and other_r!='oficial':raise ValueError('El Auditor solo tiene esta facultad excepcional sobre Oficiales Militares.')
  if not other['wanted']:raise ValueError('No hay una infracción registrada que justifique el arresto.')
  other['jail_until']=t+45;other['wanted']=0;other['crime']='';other['sector']=1;other['scene']='corridor';other['room_id']=0;other['x']=190;other['y']=310
  save_player(other)
  q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',
    (pid,'arrest',other['id'],'Arresto por infracción comprobada por el servidor.',t))
  await msg(rt,'Arresto realizado contra '+other['name'],'good');await msg(rt2,'Has sido arrestado por '+p['name']+'.', 'danger')
 elif act in ('stun','knock'):
  if role_id(p)!='oficial':raise ValueError('Solo un Oficial Militar puede utilizar este dispositivo.')
  rt2=await collision_guard(rt,str(data.get('target','')),165 if act=='stun' else 105)
  if not rt2:raise ValueError('Objetivo fuera de alcance.')
  other=rt2.p
  if not (other['wanted'] or hostile(other) or ROLE.get(role_id(other),{}).get('criminal')):
   raise ValueError('No existe causa registrada para esta neutralización.')
  if act=='stun':
   if t-rt.last_stun<75:raise ValueError('El módulo eléctrico sigue recargando.')
   rt.last_stun=t;duration=8
  else:
   if t-rt.last_knock<5:raise ValueError('Espera antes de noquear nuevamente.')
   rt.last_knock=t;duration=3
  rt2.dx=rt2.dy=0;rt2.stun_until=t+duration
  await msg(rt,('Descarga de inmovilización' if act=='stun' else 'Noqueo')+' aplicada a '+other['name'],'good')
  await msg(rt2,'Estás inmovilizado temporalmente.','danger')
 elif act=='attack':
  if t-rt.last_hit<1.2:raise ValueError('Tu acción está recargando.')
  rt.last_hit=t
  rt2=await collision_guard(rt,str(data.get('target','')),105)
  if not rt2:raise ValueError('El objetivo no está cerca.')
  other=rt2.p;r=role_id(p)
  allowed=False
  if hostile(p):allowed=True
  elif r=='oficial':
   # Being wanted for a minor offense (e.g. illegal occupancy) is not lethal authorization.
   special_criminal=ROLE.get(role_id(other),{}).get('criminal',False)
   severe=other['crime'] in ('Homicidio', 'Ataque de anomalía hostil', 'Ataque armado grave')
   allowed=hostile(other) or special_criminal or severe
  elif r=='inquisidor':allowed=hostile(other) and bool(one('SELECT 1 FROM warrants WHERE target_id=?',(other['id'],)))
  elif r=='mercenario':allowed=hostile(other)
  if not allowed:raise ValueError('No estás autorizado para emplear fuerza letal contra este objetivo.')
  dmg=35 if r=='oficial' else 24 if r=='inquisidor' else 17 if r=='mercenario' else 13
  other['health']=max(0,other['health']-dmg)
  if hostile(p):p['wanted']=1;p['crime']='Ataque de anomalía hostil'
  if other['health']<=0:
   if hostile(p):p['level']=min(99,p['level']+1);q('UPDATE players SET level=? WHERE id=?',(p['level'],pid))
   other['health']=100;other['sector']=1;other['scene']='corridor';other['room_id']=0;other['x']=190;other['y']=310
   await msg(rt2,'Has sido derrotado y regresaste al sector inicial.','danger')
  save_player(p);save_player(other)
  await msg(rt,'Objetivo alcanzado: '+other['name'],'good');await msg(rt2,'Has recibido daño de '+p['name'],'danger')
 elif act=='admin_unlock':
  code=str(data.get('code',''))
  if not admin_code or admin_code=='REEMPLAZA_CON_CODIGO_LARGO_ALEATORIO':raise ValueError('El Núcleo está desactivado en este servidor.')
  ip=rt.ws.client.host if rt.ws and rt.ws.client else 'unknown'
  failures=admin_failures[ip]
  while failures and t-failures[0]>900:failures.popleft()
  if len(failures)>=5:raise ValueError('Acceso temporalmente bloqueado.')
  if hmac.compare_digest(code,admin_code):
   rt.admin=True;q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',(pid,'admin_unlock',pid,'Sesión autorizada',t))
   await send(rt,{'type':'admin','enabled':True});await msg(rt,'Acceso concedido.','good')
  else:
   failures.append(t)
   q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',(pid,'admin_failed',pid,'Intento fallido',t))
   raise ValueError('Código no válido.')
 elif act=='admin':
  if not rt.admin:raise ValueError('Acceso denegado.')
  cmd=str(data.get('cmd',''));target_id=str(data.get('target',''))[:64]
  if cmd in ('ban','unban'):
   target=one('SELECT * FROM players WHERE id=? OR lower(name)=lower(?)',(target_id,target_id))
   if not target:raise ValueError('Jugador no encontrado.')
   if target['id']==pid:raise ValueError('No puedes banearte a ti mismo.')
   ban=int(cmd=='ban');q('UPDATE players SET banned=?,ban_reason=? WHERE id=?',(ban,'Sanción de administración' if ban else '',target['id']))
   q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',(pid,cmd,target['id'],'Acción de moderación',t))
   other=online.get(target['id'])
   if other and ban:
    await msg(other,'Tu acceso al servidor ha sido bloqueado.','danger')
    if other.ws:await other.ws.close(code=4003)
   await msg(rt,'Moderación aplicada.','good')
  elif cmd=='mask':
   role=str(data.get('role',''))
   if role not in ROLE:raise ValueError('Rol desconocido.')
   meta={'role':role}
   if role=='anomalo':meta=weighted_mask({'affinity':'anomaly'})
   ident=add_item(pid,'mask',**meta)
   if not ident:raise ValueError('Sin espacio en inventario.')
   q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',(pid,'grant_mask',pid,role,t))
   await msg(rt,'Máscara añadida al inventario.','good')
  elif cmd=='item':
   kind=str(data.get('kind',''))
   if not add_item(pid,kind):raise ValueError('Objeto desconocido o inventario lleno.')
   q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',(pid,'grant_item',pid,kind,t))
   await msg(rt,'Objeto añadido.','good')
  elif cmd=='order':
   target=one('SELECT * FROM players WHERE id=? OR lower(name)=lower(?)',(target_id,target_id))
   if not target:raise ValueError('Jugador no encontrado.')
   if not hostile(dict(target)):raise ValueError('Solo puedes emitir una orden inquisitorial sobre objetivos hostiles.')
   q('INSERT OR REPLACE INTO warrants (target_id,reason,created_at) VALUES (?,?,?)',(target['id'],'Orden contra entidad hostil',t))
   q('INSERT INTO audit (actor,action,target,detail,created_at) VALUES (?,?,?,?,?)',(pid,'order',target['id'],'Orden inquisitorial',t))
   await msg(rt,'Orden emitida.','good')
  else:raise ValueError('Comando administrativo desconocido.')
 else:raise ValueError('Acción no reconocida.')
 await refresh(rt)

async def world_loop():
 tick=time.monotonic();last_broadcast=0;last_save=0
 while True:
  await asyncio.sleep(.05)
  t=time.monotonic();dt=min(.12,t-tick);tick=t
  for rt in list(online.values()):
   if not rt.online:continue
   p=rt.p
   if p['jail_until']>now() or rt.stun_until>now():rt.dx=rt.dy=0
   vx,vy=rt.dx,rt.dy
   norm=math.hypot(vx,vy)
   if norm>1:vx/=norm;vy/=norm
   speed=205 if role_id(p)=='superviviente' else 190
   if p['scene']=='corridor':
    p['x']=min(WORLD_WIDTH-110,max(100,p['x']+vx*dt*speed))
    p['y']=min(455,max(155,p['y']+vy*dt*speed))
   else:
    p['x']=min(1010,max(90,p['x']+vx*dt*speed))
    p['y']=min(510,max(180,p['y']+vy*dt*speed))
   if p['jail_until']<=now():
    passage=now()-rt.last_food;rt.last_food=now()
    if passage>0:
     decay=(.004 if role_id(p)=='superviviente' else .005)*min(passage,1)
     p['food']=max(0,p['food']-decay);p['water']=max(0,p['water']-decay*1.2)
   rt.dirty=rt.dirty or bool(vx or vy)
  if t-last_broadcast>.18:
   last_broadcast=t
   for rt in list(online.values()):
    p=rt.p
    peers=[compact_player(o.p,p) for o in online.values() if o.p['id']!=p['id'] and o.p['sector']==p['sector'] and o.p['scene']==p['scene'] and o.p['room_id']==p['room_id']]
    scene={'type':'world','self':compact_player(p), 'players':peers,
           'npcs':corridor_npcs(p['sector']) if p['scene']=='corridor' else room_npcs(p['room_id']),
           'online':len(online), 'capsules':all_sector_capsules(p['sector']) if p['scene']=='corridor' else [],
           'room':room_for(p['room_id']) if p['scene']=='room' else None,
           'chat':[m for m in recent_chat if m['sector']==p['sector'] and m['scene']==p['scene'] and m['room']==p['room_id']][-15:]}
    await send(rt,scene)
  if t-last_save>2:
   last_save=t
   for rt in online.values():
    if rt.dirty:save_player(rt.p);rt.dirty=False

@asynccontextmanager
async def lifespan(app):
 task=asyncio.create_task(world_loop())
 try:yield
 finally:
  task.cancel()
  try:await task
  except asyncio.CancelledError:pass
  for rt in online.values():save_player(rt.p)

app=FastAPI(title='LIMEN — La Instalación',lifespan=lifespan)

class Start(BaseModel):
 token:str|None=None
 name:str|None='Habitante'

@app.post('/api/session')
async def session(data:Start):
 p=player_by_token(data.token)
 if data.token and not p:raise HTTPException(401,detail='Código de recuperación inválido o cuenta inexistente.')
 if p:
  if p['banned']:raise HTTPException(403,detail='Cuenta suspendida: '+p['ban_reason'])
  return {'token':data.token,'player':player_data(p),'roles':ROLES,'items':ITEMS}
 try:name=sanitize_name(data.name or 'Habitante')
 except ValueError as e:raise HTTPException(400,detail=str(e))
 token=secrets.token_urlsafe(40);ident=new_id();t=now()
 q('INSERT INTO players (id,token_hash,name,created_at,updated_at) VALUES (?,?,?,?,?)',
   (ident,tokenhash(token),name,t,t))
 p=player_by_token(token)
 return {'token':token,'player':player_data(p),'roles':ROLES,'items':ITEMS}

@app.get('/api/health')
async def health():return {'ok':True,'version':'0.5.0','capsules':CAPSULE_COUNT,'online':len(online)}

@app.websocket('/ws')
async def websocket(ws:WebSocket):
 await ws.accept();rt=None
 try:
  hello=await asyncio.wait_for(ws.receive_json(),timeout=8)
  if hello.get('type')!='hello':await ws.close(code=4001);return
  p=player_by_token(hello.get('token'))
  if not p or p['banned']:await ws.close(code=4003);return
  ident=p['id']
  if ident in online and online[ident].ws:
   await online[ident].ws.close(code=4002)
  rt=Runtime(p);rt.ws=ws;rt.online=True;online[ident]=rt
  await send(rt,{'type':'ready','player':player_data(p),'roles':ROLES,'items':ITEMS})
  while True:
   packet=await ws.receive_json()
   if not isinstance(packet,dict):continue
   if len(json.dumps(packet))>2048:continue
   action=packet.get('type','')
   if action=='move':
    if rt.p['jail_until']>now():rt.dx=rt.dy=0;continue
    rt.dx=max(-1,min(1,float(packet.get('dx',0))));rt.dy=max(-1,min(1,float(packet.get('dy',0))))
    rt.last_input=now()
   elif action=='action':
    try:await do_action(rt,packet)
    except (ValueError,TypeError,KeyError,sqlite3.Error) as e:await msg(rt,str(e),'danger')
   elif action=='ping':await send(rt,{'type':'pong','at':now()})
 except (WebSocketDisconnect,asyncio.TimeoutError,RuntimeError):pass
 except Exception as e:
  print('WebSocket unexpected error:',repr(e))
 finally:
  if rt:
   if online.get(rt.p['id']) is rt:
    rt.online=False;save_player(rt.p);online.pop(rt.p['id'],None)

app.mount('/',StaticFiles(directory=ROOT/'web',html=True),name='web')
