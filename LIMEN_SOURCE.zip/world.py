"""LIMEN: stable procedural world and item geometry.
No randomness affecting valuable loot is calculated by the browser.
"""
import json, random
from pathlib import Path

ROOT = Path(__file__).parent
ROLES = json.loads((ROOT / 'roles.json').read_text(encoding='utf-8'))
ROLE = {r['id']:r for r in ROLES}
CAPSULE_COUNT = 100_000
PODS_PER_SECTOR = 12
WORLD_WIDTH = 2520
ITEMS = {
 'ration': {'name':'Ración alimenticia','size':[1,1],'stack':5,'icon':'▤'},
 'water': {'name':'Agua potable','size':[1,1],'stack':5,'icon':'◈'},
 'medkit': {'name':'Botiquín','size':[2,2],'stack':3,'icon':'✚'},
 'battery': {'name':'Batería','size':[1,2],'stack':3,'icon':'ϟ'},
 'bag_small': {'name':'Mochila pequeña','size':[2,2],'stack':1,'icon':'▣'},
 'bag_medium': {'name':'Mochila mediana','size':[2,3],'stack':1,'icon':'▣'},
 'bag_large': {'name':'Mochila grande','size':[3,3],'stack':1,'icon':'▣'},
 'weapon_pistol': {'name':'Pistola de servicio','size':[2,1],'stack':1,'icon':'⌁'},
 'weapon_rifle': {'name':'Arma larga','size':[3,2],'stack':1,'icon':'⌁'},
 'scanner': {'name':'Escáner','size':[2,1],'stack':1,'icon':'⌾'},
 'armor': {'name':'Placa protectora','size':[2,2],'stack':1,'icon':'⬡'},
 'access2': {'name':'Tarjeta L2','size':[1,1],'stack':1,'icon':'▰'},
 'access3': {'name':'Tarjeta L3','size':[1,1],'stack':1,'icon':'▰'},
 'access4': {'name':'Tarjeta L4','size':[1,1],'stack':1,'icon':'▰'},
 'mask': {'name':'Máscara de clase','size':[2,2],'stack':1,'icon':'◉'},
}
BAGS = {'none':(6,3),'small':(9,3),'medium':(8,4),'large':(7,7)}
ROOMS = [
 ('home','Residencia',25,1,'home','#81bea8'),
 ('store','Depósito de suministros',11,1,'workshop','#d2b078'),
 ('medical','Departamento médico oculto',8,2,'medical','#8dddd4'),
 ('security','Puesto de Seguridad',7,2,'security','#82afe2'),
 ('military','Instalación militar',3,4,'military','#b1a7ea'),
 ('lab','Laboratorio anómalo',8,3,'lab','#b6a0e5'),
 ('containment','Cámara de contención',9,3,'containment','#e89890'),
 ('garden','Jardín hidropónico',6,1,'home','#8acf9b'),
 ('archive','Archivo histórico',5,2,'archive','#88c2e0'),
 ('comm','Centro de comunicaciones',3,2,'comm','#91d7df'),
 ('workshop','Taller técnico',7,1,'workshop','#d9af8c'),
 ('unknown','Espacio imposible',4,1,'unknown','#d6b2e9'),
 ('derelict','Módulo abandonado',4,1,'unknown','#8e9da2'),
]
ROOM_MAP = {r[0]:r for r in ROOMS}
FIRST=['home','workshop','medical','containment','store','home','comm','archive','home','lab','security','garden']

def hash32(n):
 n = n & 0xffffffff
 n = ((n ^ 0x45d9f3b) * 0x45d9f3b) & 0xffffffff
 n ^= n >> 16
 n = (n * 0x45d9f3b) & 0xffffffff
 return (n ^ (n >> 16)) & 0xffffffff

def urand(n,salt=0):
 return hash32((n & 0xffffffff) + ((salt+1)*0x9e3779b1))/4294967296

def room_for(cid):
 if not 1 <= cid <= CAPSULE_COUNT: return None
 if cid <= len(FIRST): typ=FIRST[cid-1]
 else:
  x=urand(cid,11)*sum(r[2] for r in ROOMS)
  typ=ROOMS[-1][0]
  for r in ROOMS:
   x-=r[2]
   if x<0: typ=r[0];break
 r=ROOM_MAP[typ]
 return {'id':cid,'type':r[0],'name':r[1],'access':r[3],'affinity':r[4],'color':r[5],
         'sector':(cid-1)//PODS_PER_SECTOR+1}

def capsule_pos(cid):
 slot=(cid-1)%PODS_PER_SECTOR
 return (190+(slot//2)*388,200 if slot%2==0 else 430)

def corridor_npcs(sector):
 # Most sectors have no corridor inhabitants.
 if urand(sector,135)>0.087: return []
 return [{'id':f'patrol-{sector}','name':['Operador','Residente','Técnico','Vigilante'][int(urand(sector,136)*4)],
          'x':340+int(urand(sector,138)*1750),'y':295+int(urand(sector,139)*30),'color':'#a3bcc7'}]

def room_npcs(cid):
 room=room_for(cid)
 if not room: return []
 chance={'home':.29,'medical':.7,'security':.65,'military':.55,'containment':.26,'derelict':.12,'unknown':.15,'garden':.46}.get(room['type'],.43)
 if urand(cid,200)>chance: return []
 n=2 if urand(cid,201)<.24 else 1
 names={'home':'Residente','medical':'Personal médico','security':'Agente de Seguridad','military':'Personal militar','lab':'Investigador','workshop':'Ingeniero','garden':'Cultivador','archive':'Archivista','comm':'Operador','containment':'Técnico de contención'}
 return [{'id':f'npc-{cid}-{i}','name':names.get(room['type'],'Habitante'),
          'x':540+190*i,'y':320+35*(i%2),'color':room['color']} for i in range(n)]

def weighted_mask(room):
 weighted=[(r,r['weight']*(1.5 if room['affinity']==r['affinity'] else 1)) for r in ROLES]
 role=random.choices([r for r,w in weighted],weights=[w for r,w in weighted])[0]
 result={'role':role['id'],'variant':None,'element':None,'form':None}
 if role['id']=='anomalo':
  if random.random()<.5:
   result['variant']='elemental'
   result['element']=random.choice(['Fuego','Hielo','Electricidad','Viento','Tierra','Agua','Luz','Sombras'])
  else:
   result['variant']='hostile'
   result['form']=random.choice(['Acechador filamentoso','Custodio de carne','Entidad de vidrio','Depredador axial','Forma umbral','Aberración de los conductos','Bípeda de espinas','Vigía desfigurado'])
 return result

def item_fits(existing,bag,new,at=None,ignore_id=None):
 """Rebuild a physical grid and return positions, or None if an item doesn't fit."""
 cols,rows=BAGS.get(bag,BAGS['none'])
 placed={}; used=set()
 def fits(i,x,y):
  w,h=ITEMS[i['type']]['size']
  return x>=0 and y>=0 and x+w<=cols and y+h<=rows and all((xx,yy) not in used for yy in range(y,y+h) for xx in range(x,x+w))
 def put(i,x,y):
  w,h=ITEMS[i['type']]['size']; placed[i['id']]={'x':x,'y':y,'w':w,'h':h}
  for yy in range(y,y+h):
   for xx in range(x,x+w):used.add((xx,yy))
 entries=[i for i in existing if i['id']!=ignore_id]
 if new:
  entries.append(new)
 # Explicit targeted placement first, remaining fixed positions, then autofit.
 if at and new:
  x,y=int(at[0]),int(at[1])
  if not fits(new,x,y):return None
  put(new,x,y)
 for i in entries:
  if i['id'] in placed:continue
  if i.get('x') is not None and i.get('y') is not None and fits(i,int(i['x']),int(i['y'])):put(i,int(i['x']),int(i['y']))
 for i in entries:
  if i['id'] in placed:continue
  found=False
  for y in range(rows):
   for x in range(cols):
    if fits(i,x,y):put(i,x,y);found=True;break
   if found:break
  if not found:return None
 return placed
