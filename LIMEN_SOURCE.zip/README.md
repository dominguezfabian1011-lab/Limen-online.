# LIMEN Online — v0.5 · La Instalación

Este proyecto continúa el concepto de **LIMEN v0.4**, pero añade un **servidor multijugador real**. Ya no es un único HTML que simula un juego en línea.

## Lo que sí funciona

- Servidor HTTP + WebSocket: varios jugadores ven sus posiciones en un mismo sector o cápsula y pueden comunicarse en el chat local.
- **100.000 cápsulas procedimentales**, repartidas en sectores de 12, con 13 tipos de interiores y acceso mediante tarjetas electrónicas. No se cargan 100.000 habitaciones a la vez.
- **29 clases** recuperadas de v0.4, incluidos nueve roles militares, Policía, Inquisidor, Director de Zona y Oficial Militar de Seguridad.
- Máscaras encontrables con **probabilidades validadas en el servidor**, más frecuentes en cápsulas relacionadas con la clase. Director y Oficial Militar son los hallazgos más raros.
- La máscara Anómalo determina aleatoriamente si transforma al jugador en humano elemental o entidad hostil, y asigna poderes/forma no elegibles (la evolución visual completa aún no está implementada).
- Inventario con **objetos de varias casillas**; mochilas de **18, 27, 32 y 49** espacios, equipar máscara por decisión del jugador.
- Una vivienda reclamable por jugador, compartida entre todos los usuarios y almacenada en base de datos.
- En la residencia propia, dispensador de una ración cada **20 segundos**. Mochilas, máscaras, armas, tarjetas y otros objetos proceden de exploración y hallazgos.
- NPC muy raros en pasillos (aprox. 8,7% de sectores) y más probables —pero no garantizados— en algunas cápsulas.
- Arrestos y un sistema inicial de infracciones con comprobaciones de clase y cercanía. Dormir dentro de la vivienda reclamada por otro jugador genera un registro de infracción.
- Reglas iniciales de fuerza letal: un **Inquisidor** necesita una orden y un objetivo anómalo hostil; un **Oficial Militar** puede atacar objetivos hostiles o buscados sin una orden inquisitorial; un **Mercenario** puede combatir anomalías hostiles. No se pueden atacar civiles arbitrariamente.
- Sistema de reconocimiento de Infiltrados del Oficial Militar, **solo por proximidad real**. Inmovilizador eléctrico de 8 segundos con 75 segundos de recarga y golpe de noqueo breve; exigen una causa registrada.
- Cuentas de invitado con token privado, guardado de personajes, objetos, máscaras, viviendas y sanciones en **SQLite** (no en el almacenamiento local del cliente).
- Código de recuperación para usar el mismo personaje en otro navegador o dispositivo. **Trátalo como contraseña**.
- Menú con opciones de idioma: español, inglés, portugués y ruso (parte del contenido narrativo/clases aún está en español).
- Índice oculto de palabras; **«El Nucleo»** abre un campo de código sin explicación. El servidor verifica la clave y mantiene la identidad de administrador invisible para otros jugadores.
- Administración por servidor: sancionar, desbanear, emitir órdenes inquisitoriales y conceder objetos y máscaras; operaciones registradas en la tabla `audit`.
- Interfaz horizontal, controles táctiles, botón de pantalla completa y manifiesto instalable para móviles.

## Iniciar en una computadora

Necesitas **Python 3.11+**, una terminal y navegador moderno.

```bash
cd LIMEN_Online_v0.5
python -m pip install -r requirements.txt
```

**Linux/macOS:**

```bash
export LIMEN_ADMIN_CODE='UNA_CLAVE_LARGA_PRIVADA_AQUI'
python -m uvicorn server:app --host 0.0.0.0 --port 8000 --workers 1
```

**Windows PowerShell:**

```powershell
$env:LIMEN_ADMIN_CODE='UNA_CLAVE_LARGA_PRIVADA_AQUI'
python -m uvicorn server:app --host 0.0.0.0 --port 8000 --workers 1
```

Abre `http://localhost:8000` en la computadora. Otros dispositivos conectados a la **misma red** pueden usar `http://IP_DE_TU_PC:8000` si tu firewall lo permite. Esto NO publica el juego en Internet.

`LIMEN_ADMIN_CODE` es una variable privada del servidor. **No la pongas en el HTML, el JavaScript ni en un repositorio público**. Si la omites, la entrada oculta estará desactivada.

## Ejecutar con Docker

```bash
docker build -t limen-online .
docker volume create limen-data
docker run --rm -p 8000:8000 \
  -e LIMEN_ADMIN_CODE='UNA_CLAVE_LARGA_PRIVADA_AQUI' \
  -v limen-data:/app/data limen-online
```

La base se almacena en `/app/data/limen.sqlite3` dentro del volumen persistente. En un alojamiento externo, configura almacenamiento persistente y **HTTPS/WSS**.

## Publicación en Internet

1. Contrata o conecta un proveedor que ejecute contenedores Docker o aplicaciones Python **con WebSockets**.
2. Despliega este proyecto como **un solo proceso** del servidor (`uvicorn`, un worker). El `Dockerfile` ya está incluido.
3. Configura `LIMEN_ADMIN_CODE` como variable secreta, no dentro del repositorio.
4. Añade volumen persistente a `/app/data` o usa `LIMEN_DB_PATH` para apuntar a una base en disco persistente.
5. Activa HTTPS y comprueba dos conexiones desde diferentes dispositivos.
6. Configura copias de seguridad de la base SQLite y restauración.

No es posible generar una URL pública real solo descargando este ZIP; el servidor debe mantenerse encendido en el alojamiento elegido. Alojamiento estático (como GitHub Pages) **no** puede ejecutar este backend.

## Diferencias importantes respecto al prototipo local

- **La partida v0.4 del navegador no se importa automáticamente al servidor**, porque sus inventarios y rarezas podían modificarse desde el propio cliente. Importarlos sin validación permitiría duplicar máscaras extraordinarias. El mundo, sus clases y sus reglas sí se conservaron.
- La versión 0.5 es una **base online jugable**, no un MMORPG terminado: están pendientes muchas habilidades específicas de clase, PNJ complejos con rutinas completas, combate avanzado, animaciones detalladas, juicio de delitos completo y misiones.
- Los permisos especiales de Oficial, Inquisidor, Policía y Auditor tienen una primera implementación. La jurisdicción del Juez y la investigación de pruebas del Auditor requieren interfaces y sistemas adicionales antes de considerarse completos.
- Las cuentas son **de invitado**. La recuperación depende de conservar su token. Para producción a gran escala convienen cuentas verificadas, recuperación segura y protección contra bots.
- SQLite + procesos en memoria está preparado para **una instancia y grupos pequeños de jugadores**. Para miles de usuarios se necesitarán PostgreSQL, Redis, gestión de sesiones distribuidas y optimizaciones de red.

## Archivos

- `server.py`: autenticación, WebSockets, persistencia, reglas del servidor, moderación.
- `world.py`: universo procedural, catálogo de interiores y geometría de inventario.
- `roles.json`: las 29 clases y marcas de máscara recuperadas del diseño de v0.4.
- `web/index.html`, `web/style.css`, `web/game.js`: cliente jugable para ordenador y móvil.
- `web/manifest.webmanifest`, `web/sw.js`, `web/assets`: iconos y modo instalable.
- `Dockerfile` y `requirements.txt`: ejecución y despliegue.
- `tests`: pruebas de dos conexiones, vivienda, inventario, arrestos, permisos y sesión.
- `legacy/LIMEN_Offline_v0.4.html`: copia del prototipo local anterior para conservarlo mientras desarrollamos la versión online.

## Privacidad y seguridad

El código del Administrador no forma parte del archivo del juego. Solo se verifica del lado del servidor. Las cuentas de invitado, los cambios de inventario y las infracciones son validados allí. Los registros de auditoría no sustituyen un sistema de moderación profesional. Usa contraseñas largas, HTTPS/WSS, copias de seguridad y límites de uso antes de abrir el juego a desconocidos.
