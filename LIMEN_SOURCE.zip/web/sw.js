const CACHE='limen-online-v0.5-static-1';
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(['/style.css','/game.js','/assets/icon192.png','/assets/icon512.png'])).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{const url=new URL(e.request.url);if(e.request.method!=='GET'||url.pathname.startsWith('/api/')||url.pathname==='/ws')return;if(url.pathname==='/'){e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)));return}e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)))});
